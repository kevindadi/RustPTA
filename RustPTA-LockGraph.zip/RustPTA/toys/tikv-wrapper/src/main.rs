mod util;
use std::sync::{Arc, RwLock};
use util::HandyRwLock;

struct Foo {
    inner: Arc::<RwLock<i32>>,
    data: i32,
}

impl Foo {
    fn new() -> Self {
        Self {
            inner: Arc::new(RwLock::new(1)), 
            data: 1,
        }
    }
    fn foo(&self) {
        match *self.inner.rl() { //18 NodeIndex(2), Local: _4
            1 => *self.inner.wl() += 1, //19 NodeIndex(2), Local: _10
            _ => {}
        };
    }
    fn bar(&self) -> i32 {
        self.data
    }
}

fn main() {
    let f = Foo::new();
    f.foo();
    f.bar();
}
