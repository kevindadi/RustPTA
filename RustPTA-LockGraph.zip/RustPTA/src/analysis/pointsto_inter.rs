//! 域敏感、上下文不敏感的过程间指针分析 
//! 基于Andesen算法
extern crate rustc_hash;
extern crate rustc_hir;
extern crate rustc_index;


use std::cmp::{Ordering, PartialOrd};
use std::collections::VecDeque;
use std::fs::File;
use std::io::Write;

use rustc_hash::{FxHashMap, FxHashSet};
use rustc_middle::mir::visit::Visitor;
use rustc_middle::mir::{
    Body, Constant, ConstantKind, Local, Location, Operand, Place, PlaceRef,
    ProjectionElem, Rvalue, Statement, StatementKind, Terminator, TerminatorKind,LocalDecl,LocalKind,
};
use rustc_middle::ty::{self,Instance, TyCtxt, TyKind,ParamEnv,ClosureArgs};

use petgraph::dot::{Config, Dot};
use petgraph::graph::NodeIndex;
use petgraph::visit::EdgeRef;
use petgraph::{Directed, Direction, Graph};

use crate::concurrency::locks::LockGuardId;
use crate::graph::callgraph::{CallGraph, CallGraphNode, InstanceId};
use crate::memory::ownership;


/// 指针分析
pub struct Andersen<'a,'tcx> {
    tcx: TyCtxt<'tcx>,
    pts: PointsToMap<'tcx>,
    callgraph: &'a CallGraph<'tcx>,
    
}

pub type PointsToMap<'tcx> = FxHashMap<ConstraintNode<'tcx>, FxHashSet<ConstraintNode<'tcx>>>;

impl<'a, 'tcx> Andersen<'a,'tcx> {
    pub fn new(tcx: TyCtxt<'tcx>, callgraph: &'a CallGraph<'tcx>,) -> Self {
        Self {
            tcx,
            pts: Default::default(),
            callgraph,
        }
    }

    pub fn analyze(
        &mut self,
        param_env: ParamEnv<'tcx>,
        instances: Vec<&'a Instance<'tcx>>,
    ) {
        let instance_first = instances[0];
        let body_first = self.tcx.instance_mir(instance_first.def);
        let mut consG_collector = ConstraintGraphCollector::new(instance_first, body_first, self.tcx,self.callgraph,param_env);
        consG_collector.analyze(instances);
        let mut graph = consG_collector.finish();

        let mut worklist = VecDeque::new();
        // alloc: place = alloc
        for node in graph.nodes() {
            match node {
                ConstraintNode::Place(place,instance_id) => {
                    graph.add_alloc(place,instance_id);
                }
                ConstraintNode::Constant(constant,instance_id) => {
                    graph.add_constant(constant,instance_id);
                    // For constant C, track *C.
                    worklist.push_back(ConstraintNode::ConstantDeref(constant,instance_id));
                }
                _ => {}
            }
            worklist.push_back(node);
        }

        // address: target = &source
        for (source, target, weight) in graph.edges() {
            if weight == ConstraintEdge::Address {
                if matches!(source, ConstraintNode::Place(_,_)) {
                    // _16 = &_3 需要pts(_16) = pts(_3)
                    if graph.insert_edge(source, target, ConstraintEdge::AddressCopy) {
                        worklist.push_back(target);
                    }
                }else{
                    self.pts.entry(target).or_default().insert(source);
                    worklist.push_back(target);
                }
                
            }
        }
        
        while let Some(node) = worklist.pop_front() {
            if !self.pts.contains_key(&node) {
                continue;
            }
            for o in self.pts.get(&node).unwrap() {
                // store: *node = source
                for source in graph.store_sources(&node) {
                    if graph.insert_edge(source, *o, ConstraintEdge::Copy) {
                        worklist.push_back(source);
                    }
                }
                // load: target = *node
                for target in graph.load_targets(&node) {
                    if graph.insert_edge(*o, target, ConstraintEdge::Copy) {
                        worklist.push_back(*o);
                    }
                }
            }
            // alias_copy: target = &X; X = ptr::read(node)
            for target in graph.alias_copy_targets(&node) {
                if graph.insert_edge(node, target, ConstraintEdge::Copy) {
                    worklist.push_back(node);
                }
            }
            // address_copy: a=&b b是Place类型 不是Alloc类型 target = &node
            for target in graph.address_copy_targets(&node) {
                if self.equal_pts(&target, &node) { //应该是直接等于
                    worklist.push_back(target);
                }
            }
            //field_address _1.0 target <-- node _1
            for target in graph.field_address_targets(&node) {
                //根据node 创建 alloc域节点
                let source_nodes = self.pts.get(&node).unwrap().clone();
                let fnodes = graph.getFieldAllocNodes(source_nodes,target);
                let len1 = self.pts.get(&target).unwrap().len();
                for fnode in fnodes{
                    graph.get_or_insert_node(fnode);
                    graph.insert_edge(fnode, target, ConstraintEdge::Address);
                    self.pts.entry(target).or_default().insert(fnode);//    
                }
                let len2 = self.pts.get(&target).unwrap().len();
                if len1 != len2{
                    worklist.push_back(target);
                }
            }
            // copy: target = node
            for target in graph.copy_targets(&node) {
                if self.union_pts(&target, &node) {
                    worklist.push_back(target);
                }
            }
        }
        
        graph.dot();//dot输出constraint graph
    }

    /// pts(target) = pts(target) U pts(source), 如果pts(target)改变，返回true
    fn union_pts(&mut self, target: &ConstraintNode<'tcx>, source: &ConstraintNode<'tcx>) -> bool {
        if matches!(target, ConstraintNode::Alloc(_,_)) {
            return false;
        }
        let old_len = self.pts.get(target).unwrap().len();
        let source_pts = self.pts.get(source).unwrap().clone();
        let target_pts = self.pts.get_mut(target).unwrap();
        target_pts.extend(source_pts.into_iter());
        old_len != target_pts.len()
    }

   fn equal_pts(&mut self, target: &ConstraintNode<'tcx>, source: &ConstraintNode<'tcx>) -> bool {
        let source_pts = self.pts.get(source).unwrap();
        let target_pts = self.pts.get(target).unwrap();
        if source_pts.eq(target_pts){
            return false
        }
        self.pts.insert(*target, source_pts.clone());
        true
    } 

    /// target <-- source
    pub fn finish(self) -> FxHashMap<ConstraintNode<'tcx>, FxHashSet<ConstraintNode<'tcx>>> {
        self.pts
    }

    /// 检查 MutexGuard是从哪里得到的，如果不是从Mutex里得到的（比如参数），则返回false
    pub fn checkGuardSource(
        & self,
        node:ConstraintNode<'tcx>,
        instance:&Instance<'tcx>,
        instance_id:NodeIndex,
    ) -> bool{
        if let Some(set) = self.pts.get(&node){
            for n in set{
                match n {
                    ConstraintNode::Alloc(place_ref_n, instance_id_n) => {
                        if *instance_id_n == instance_id{
                            let body = self.tcx.instance_mir(instance.def);
                            for (local, local_ty) in body.local_decls.iter_enumerated(){
                                // println!("local{:?},local_ty{:?}",local,local_ty.ty);
                                // println!("loalty sort_string{:?}",local_ty.ty.sort_string(self.tcx));
                                let cow = local_ty.ty.sort_string(self.tcx).into_owned();
                                let path =cow.as_str();
                                // println!("cow{:?}",path);
                                if !path.contains("Guard"){
                                            //Result 是unwrap() 之前吗
                                            if path.contains("Mutex") || path.contains("RwLock") || path.contains("Result") || path.contains("Arc")
                                                || path.contains("parking_lot") || path.contains("spin") || path.contains("sync")
                                            {
                                
                                                return true;
                                            }
                                           
                                    }
                                // if let ty::TyKind::Adt(adt_def, substs)= local_ty.ty.kind() {
                                //     // let path = self.tcx.def_path_str_with_args(adt_def.did(),substs);
                                //     let path = self.tcx.def_path_str(adt_def.did());
                                //     println!("isntance_id{:?},local{:?},path:{:?}",instance_id,local,path);
                                //     if !path.contains("Guard"){
                                //         //Result 是unwrap() 之前吗
                                //         if path.contains("Mutex") || path.contains("RwLock") || path.contains("Result") || path.contains("Arc")
                                //             || path.contains("parking_lot") || path.contains("spin") || path.contains("sync")
                                //         {
                                           
                                //             return true;
                                //         }
                                       
                                //     }
                                // }
                               
                            }
                           
                        }
                       
                    },
                    _=> {}
                }
            }
        }
        false
    }

    /// 检查两个变量间是否存在别名关系
    pub fn alias( 
        &mut self, 
        aid1: AliasId, 
        aid2: AliasId,
        param_env: ParamEnv<'tcx>,
    ) -> ApproximateAliasKind {
        
        let AliasId {
            instance_id: id1,
            local: local1,
        } = aid1;
        let AliasId {
            instance_id: id2,
            local: local2,
        } = aid2;

        let instance1 = self
            .callgraph
            .index_to_instance(id1)
            .map(CallGraphNode::instance);
        let instance2 = self
            .callgraph
            .index_to_instance(id2)
            .map(CallGraphNode::instance);
        let node1 = ConstraintNode::Place(Place::from(local1).as_ref(),id1);
        let node2 = ConstraintNode::Place(Place::from(local2).as_ref(),id2);
        let set1 = self.pts.get(&node1);
        let set2 = self.pts.get(&node2);
        if id1 != id2{ //在不同instance时 才检查MutexGuard来源
            if let (Some(instance1), Some(instance2)) = (instance1, instance2){
                //检测Guard 是否是从Mutex或者RwLock里得到
                let flag1 = self.checkGuardSource(node1, instance1, id1);
                // println!("instance_id{:?},flag{:?}",id1,flag1);
                let flag2 = self.checkGuardSource(node2, instance2, id2);
                // println!("instance_id{:?},flag{:?}",id2,flag2);
                if flag1 && flag2{
                    if let (Some(set1), Some(set2)) = (set1, set2) {
                        if set2.contains(&node1) || set1.contains(&node2) {
                            ApproximateAliasKind::Probably
                        } else {
                            let intersection = set1.intersection(set2);
                            if intersection.count() > 0 {
                                ApproximateAliasKind::Probably
                            } else {
                                ApproximateAliasKind::Unlikely
                            }
                        }
                    } 
                    else if let Some(set2) = set2 {
                        if set2.contains(&node1) {
                            ApproximateAliasKind::Probably
                        } else {
                            ApproximateAliasKind::Unlikely
                        }
                    } else if let Some(set1) = set1 {
                        if set1.contains(&node2) {
                            ApproximateAliasKind::Probably
                        } else {
                            ApproximateAliasKind::Unlikely
                        }
                    }
                    else {
                        ApproximateAliasKind::Unlikely
                    }
                }else {
                    ApproximateAliasKind::Unlikely
                }
            }else {
                ApproximateAliasKind::Unlikely
            }
        }else{
            if let (Some(set1), Some(set2)) = (set1, set2) {
                if set2.contains(&node1) || set1.contains(&node2) {
                    ApproximateAliasKind::Probably
                } else {
                    let intersection = set1.intersection(set2);
                    if intersection.count() > 0 {
                        ApproximateAliasKind::Probably
                    } else {
                        ApproximateAliasKind::Unlikely
                    }
                }
            } else if let Some(set2) = set2 {
                if set2.contains(&node1) {
                    ApproximateAliasKind::Probably
                } else {
                    ApproximateAliasKind::Unlikely
                }
            } else if let Some(set1) = set1 {
                if set1.contains(&node2) {
                    ApproximateAliasKind::Probably
                } else {
                    ApproximateAliasKind::Unlikely
                }
            }
            else {
                ApproximateAliasKind::Unlikely
            }
            
        }
        
       
        
    }
    
    

    /// 检查是否pointer指向pointee
    pub fn points(
        &mut self, 
        pointer: AliasId, 
        pointee: AliasId,
        param_env: ParamEnv<'tcx>,
    ) -> ApproximateAliasKind {
        
        let AliasId {
            instance_id: id1,
            local: local1,
        } = pointer;
        let AliasId {
            instance_id: id2,
            local: local2,
        } = pointee;

        let instance1 = self
            .callgraph
            .index_to_instance(id1)
            .map(CallGraphNode::instance);
        let instance2 = self
            .callgraph
            .index_to_instance(id2)
            .map(CallGraphNode::instance);
        let node1 = ConstraintNode::Place(Place::from(local1).as_ref(),id1);
        let node2 = ConstraintNode::Place(Place::from(local2).as_ref(),id2);
        let node2_alloc =  ConstraintNode::Alloc(Place::from(local2).as_ref(),id2); //
        let set1 = self.pts.get(&node1);
       
        // println!("PROCESS POINTS.........");
        if let Some(set1) = set1 {
            if set1.contains(&node2_alloc) {
                ApproximateAliasKind::Probably
            } else {
                ApproximateAliasKind::Unlikely
            }
        } 
        else {
            ApproximateAliasKind::Unlikely
        }
        
    }

    pub fn get_pts(&mut self) ->&PointsToMap<'tcx>{
        &self.pts
    }
    
}

/// AliasId和LockGuardId有相同信息
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct AliasId {
    pub instance_id: InstanceId,
    pub local: Local,
}
impl std::convert::From<LockGuardId> for AliasId {
    fn from(lockguard_id: LockGuardId) -> Self {
        Self {
            instance_id: lockguard_id.instance_id,
            local: lockguard_id.local,
        }
    }
}
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
pub enum ApproximateAliasKind {
    Probably,
    Possibly,
    Unlikely,
    Unknown,
}
impl ApproximateAliasKind {
    pub fn to_string(&self) -> String {
        match self {
            ApproximateAliasKind::Probably => String::from("Probably"),
            ApproximateAliasKind::Possibly => String::from("Possibly"),
            ApproximateAliasKind::Unlikely => String::from("Unlikely"),
            ApproximateAliasKind::Unknown => String::from("Unknown"),
        }
    }
}

impl PartialOrd for ApproximateAliasKind {
    // Probably > Possibly > Unlikey > Unknown
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        use ApproximateAliasKind::*;
        match (*self, *other) {
            (Probably, Probably)
            | (Possibly, Possibly)
            | (Unlikely, Unlikely)
            | (Unknown, Unknown) => Some(Ordering::Equal),
            (Probably, _) | (Possibly, Unlikely) | (Possibly, Unknown) | (Unlikely, Unknown) => {
                Some(Ordering::Greater)
            }
            (_, Probably) | (Unlikely, Possibly) | (Unknown, Possibly) | (Unknown, Unlikely) => {
                Some(Ordering::Less)
            }
        }
    }
}


/// 约束图结点
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ConstraintNode<'tcx> {
    Alloc(PlaceRef<'tcx>,InstanceId),
    Place(PlaceRef<'tcx>,InstanceId),
    Constant(ConstantKind<'tcx>,InstanceId),
    ConstantDeref(ConstantKind<'tcx>,InstanceId),
}

/// 约束图的边
#[derive(Debug, Clone, Copy, PartialEq, Eq,Hash)]
enum ConstraintEdge {
    Address,// a = &b
    Copy,// a = b
    Load,// a = *b 
    Store,//*a = b  
    AliasCopy, // Special: y=Arc::clone(x) or y=ptr::read(x)
    AddressCopy,// a = &b Place(b)
    FieldAddress,//a = &((*b).0)
}

enum AccessPattern<'tcx> {
    Ref(PlaceRef<'tcx>),
    Indirect(PlaceRef<'tcx>),
    Direct(PlaceRef<'tcx>),
    Constant(ConstantKind<'tcx>),
    Field(PlaceRef<'tcx>),
}

/// 约束图
#[derive(Default)]
struct ConstraintGraph<'tcx> {
    graph: Graph<ConstraintNode<'tcx>, ConstraintEdge, Directed>,
    node_map: FxHashMap<ConstraintNode<'tcx>, NodeIndex>,
    edges:FxHashSet<(NodeIndex,NodeIndex,ConstraintEdge)>,
}

impl<'tcx> ConstraintGraph<'tcx> {
    pub fn get_or_insert_node(&mut self, node: ConstraintNode<'tcx>) -> NodeIndex {
        if let Some(idx) = self.node_map.get(&node) {
            *idx
        } else {
            let idx = self.graph.add_node(node);//添加节点
            self.node_map.insert(node, idx);
            idx
        }
    }

    pub fn get_node(&self, node: &ConstraintNode<'tcx>) -> Option<NodeIndex> {
        self.node_map.get(node).copied()
    }
    pub fn getFieldAllocNodes(&mut self,source_nodes:FxHashSet<ConstraintNode<'tcx>>,target:ConstraintNode<'tcx>) -> FxHashSet<ConstraintNode<'tcx>>{
        
        let mut fieldAllocNodes = FxHashSet::default();
        for s in source_nodes{
            match (s,target) {
                (ConstraintNode::Alloc(place_ref1, instance_id1),ConstraintNode::Place(place_ref2,instance_id2 )) => {
                    match place_ref2 {
                        PlaceRef {
                            local: l,
                            projection: p,
                        } => {
                            if let Some(new_local) = place_ref1.as_local(){ 
                                //place_ref1 ： 如果是_1.0 呢
                                let new_node = ConstraintNode::Alloc(PlaceRef {
                                    local: new_local,
                                    projection: p, //
                                }, instance_id1);
                
                                fieldAllocNodes.insert(new_node);
                            }
                        }  
                        _ => {},
                    }  
                }
                _=> {}
            }
        }
        fieldAllocNodes
    }
    pub fn add_edge_check(&mut self,rhs:NodeIndex,lhs:NodeIndex,edgeTy:ConstraintEdge){
        if !self.edges.contains(&(rhs,lhs,edgeTy)){
            self.edges.insert((rhs,lhs,edgeTy));
            self.graph.add_edge(rhs, lhs, edgeTy);
        }
    }
    
    fn add_alloc(&mut self, place: PlaceRef<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(place,instanceid);
        let rhs = ConstraintNode::Alloc(place,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Address);
        
    }

    fn add_constant(&mut self, constant: ConstantKind<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Constant(constant,instanceid);
        let rhs = ConstraintNode::ConstantDeref(constant,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Address);
        self.add_edge_check(rhs, rhs, ConstraintEdge::Address);
    }

    fn add_address(&mut self, lhs: PlaceRef<'tcx>, rhs: PlaceRef<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Place(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Address);
    }

    fn add_copy(&mut self, lhs: PlaceRef<'tcx>, rhs: PlaceRef<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Place(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Copy);
    }

    fn add_copy_constant(&mut self, lhs: PlaceRef<'tcx>, rhs: ConstantKind<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Constant(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Copy);
    }

    fn add_load(&mut self, lhs: PlaceRef<'tcx>, rhs: PlaceRef<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Place(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Load);
    }

    fn add_store(&mut self, lhs: PlaceRef<'tcx>, rhs: PlaceRef<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Place(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Store);
    }
    fn add_call_arg(&mut self, real: PlaceRef<'tcx>, formal: PlaceRef<'tcx>, call_instanceid:InstanceId,callee_instanceid:InstanceId) {
        let real = ConstraintNode::Place(real,call_instanceid);
        let formal = ConstraintNode::Place(formal,callee_instanceid);
        let real = self.get_or_insert_node(real);
        let formal = self.get_or_insert_node(formal);
        self.add_edge_check(real, formal, ConstraintEdge::Copy);
        
    }
    fn add_store_constant(&mut self, lhs: PlaceRef<'tcx>, rhs: ConstantKind<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Constant(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::Store);
    }

    fn add_alias_copy(&mut self, lhs: PlaceRef<'tcx>, rhs: PlaceRef<'tcx>, instanceid:InstanceId) {
        let lhs = ConstraintNode::Place(lhs,instanceid);
        let rhs = ConstraintNode::Place(rhs,instanceid);
        let lhs = self.get_or_insert_node(lhs);
        let rhs = self.get_or_insert_node(rhs);
        self.add_edge_check(rhs, lhs, ConstraintEdge::AliasCopy);
    }

   
    fn add_closure(&mut self, capture: PlaceRef<'tcx>, closure_arg: PlaceRef<'tcx>, instanceid:InstanceId,closure_instanceid:InstanceId) {
        let real = ConstraintNode::Place(capture,instanceid);
        let closure_arg = ConstraintNode::Place(closure_arg,closure_instanceid);
        let real = self.get_or_insert_node(real);
        let closure_arg = self.get_or_insert_node(closure_arg);
        self.add_edge_check(real, closure_arg, ConstraintEdge::Copy);
        
    }
    fn add_field_address(&mut self, lhs: PlaceRef<'tcx>, rhs: PlaceRef<'tcx>, instanceid:InstanceId){
        // _8 = &((*_1).0
        //lhs:_8; rhs:((*_1).0: std::sync::Arc<std::sync::Mutex<i32>>)
        if let Some(field_var) = self.get_field_var(rhs){
            let lhs = ConstraintNode::Place(lhs,instanceid);
            let field_nodes = ConstraintNode::Place(rhs,instanceid);//
            let rhs = ConstraintNode::Place(rhs,instanceid);
            
            let field_var = ConstraintNode::Place(field_var,instanceid);//_1
            let lhs = self.get_or_insert_node(lhs);
            let rhs = self.get_or_insert_node(rhs);
            let field_var = self.get_or_insert_node(field_var);
            self.add_edge_check(field_var, rhs, ConstraintEdge::FieldAddress); // _1 ---> _1.0 
            self.add_edge_check(rhs, lhs, ConstraintEdge::Address);
        }
    }
    fn get_field_var(& mut self,rvalue:PlaceRef<'tcx>) -> Option<PlaceRef<'tcx>>{  

        match rvalue {
            PlaceRef {
                local: l,
                projection: [..,ProjectionElem::Field(_, _),],
            } => Some(Place::from(l).as_ref()),  
            _ => None,
        }
    }
    fn nodes(&self) -> Vec<ConstraintNode<'tcx>> {
        self.node_map.keys().copied().collect::<_>()
    }

    fn edges(&self) -> Vec<(ConstraintNode<'tcx>, ConstraintNode<'tcx>, ConstraintEdge)> {
        let mut v = Vec::new();
        for edge in self.graph.edge_references() {
            let source = self.graph.node_weight(edge.source()).copied().unwrap();
            let target = self.graph.node_weight(edge.target()).copied().unwrap();
            let weight = *edge.weight();
            v.push((source, target, weight));
        }
        v
    }

    /// *lhs = ?
    /// ?--|store|-->lhs
    fn store_sources(&self, lhs: &ConstraintNode<'tcx>) -> Vec<ConstraintNode<'tcx>> {
        let lhs = self.get_node(lhs).unwrap();
        let mut sources = Vec::new();
        for edge in self.graph.edges_directed(lhs, Direction::Incoming) {
            if *edge.weight() == ConstraintEdge::Store {
                let source = self.graph.node_weight(edge.source()).copied().unwrap();
                sources.push(source);
            }
        }
        sources
    }

    /// ? = *rhs
    /// rhs--|load|-->?
    fn load_targets(&self, rhs: &ConstraintNode<'tcx>) -> Vec<ConstraintNode<'tcx>> {
        let rhs = self.get_node(rhs).unwrap();
        let mut targets = Vec::new();
        for edge in self.graph.edges_directed(rhs, Direction::Outgoing) {
            if *edge.weight() == ConstraintEdge::Load {
                let target = self.graph.node_weight(edge.target()).copied().unwrap();
                targets.push(target);
            }
        }
        targets
    }

    /// ? = rhs
    /// rhs--|copy|-->?
    fn copy_targets(&self, rhs: &ConstraintNode<'tcx>) -> Vec<ConstraintNode<'tcx>> {
        let rhs = self.get_node(rhs).unwrap();
        let mut targets = Vec::new();
        for edge in self.graph.edges_directed(rhs, Direction::Outgoing) {
            if *edge.weight() == ConstraintEdge::Copy {
                let target = self.graph.node_weight(edge.target()).copied().unwrap();
                targets.push(target);
            }
        }
        targets
    }

    /// a = &b b是Place 不是Alloc  ?=&rhs
    fn address_copy_targets(&self, rhs: &ConstraintNode<'tcx>) -> Vec<ConstraintNode<'tcx>> {
        let rhs = self.get_node(rhs).unwrap();
        let mut targets = Vec::new();
        for edge in self.graph.edges_directed(rhs, Direction::Outgoing) {
            if *edge.weight() == ConstraintEdge::AddressCopy {
                let target = self.graph.node_weight(edge.target()).copied().unwrap();
                targets.push(target);
            }
        }
        targets
    }

    /// (*_1).0 <--|FieldAddress|-- _1
    fn field_address_targets(&self, rhs: &ConstraintNode<'tcx>) -> Vec<ConstraintNode<'tcx>> {
        let rhs = self.get_node(rhs).unwrap();
        let mut targets = Vec::new();
        for edge in self.graph.edges_directed(rhs, Direction::Outgoing) {
            if *edge.weight() == ConstraintEdge::FieldAddress {
                let target = self.graph.node_weight(edge.target()).copied().unwrap();
                targets.push(target);
            }
        }
        targets
    }
    /// X = Arc::clone(rhs) or X = ptr::read(rhs)
    /// ? = &X
    ///
    /// rhs--|alias_copy|-->X,
    /// X--|address|-->?
    fn alias_copy_targets(&self, rhs: &ConstraintNode<'tcx>) -> Vec<ConstraintNode<'tcx>> {
        let rhs = self.get_node(rhs).unwrap();
        self.graph
            .edges_directed(rhs, Direction::Outgoing)
            .filter_map(|edge| {
                if *edge.weight() == ConstraintEdge::AliasCopy {
                    Some(edge.target())
                } else {
                    None
                }
            })
            .fold(Vec::new(), |mut acc, copy_alias_target| {
                let address_targets = self
                    .graph
                    .edges_directed(copy_alias_target, Direction::Outgoing)
                    .filter_map(|edge| {
                        if *edge.weight() == ConstraintEdge::Address {
                            Some(self.graph.node_weight(edge.target()).copied().unwrap())
                        } else {
                            None
                        }
                    });
                acc.extend(address_targets);
                acc
            })
    }

    /// if edge `from--|weight|-->to` not exists,
    /// then add the edge and return true
    fn insert_edge(
        &mut self,
        from: ConstraintNode<'tcx>,
        to: ConstraintNode<'tcx>,
        weight: ConstraintEdge,
    ) -> bool {
        let from = self.get_node(&from).unwrap();
        let to = self.get_node(&to).unwrap();
        if let Some(edge) = self.graph.find_edge(from, to) {
            if let Some(w) = self.graph.edge_weight(edge) {
                if *w == weight {
                    return false;
                }
            }
        }
        self.add_edge_check(from, to, weight);
        true
    }

    /// Print the ConstarintGraph in dot format.
    #[allow(dead_code)]
    pub fn dot(&self) {
        let dot_string = format!("digraph G {{\n{:?}\n}}", Dot::with_config(&self.graph, &[Config::GraphContentOnly]));
        let output_file_path = "ConstraintGraph_pt.dot";
        match File::create(output_file_path) {
            Ok(mut file) => {
                if let Err(err) = file.write_all(dot_string.as_bytes()) {
                    eprintln!("Failed to write to file: {}", err);
                } else {
                    // println!("DOT representation saved to '{}'", output_file_path);
                }
            },
            Err(err) => {
                eprintln!("Failed to create file: {}", err);
            }
        }
    }
}

/// 遍历MIR body，生成约束图
struct ConstraintGraphCollector<'a, 'tcx> {
    instance: &'a Instance<'tcx>,
    body: &'a Body<'tcx>,
    tcx: TyCtxt<'tcx>,
    graph: ConstraintGraph<'tcx>,
    callgraph: &'a CallGraph<'tcx>,
    worklist_instance: VecDeque<NodeIndex>,
    param_env: ParamEnv<'tcx>,
}

impl<'a, 'tcx> ConstraintGraphCollector<'a, 'tcx> {
    fn new(instance: &'a Instance<'tcx>,body: &'a Body<'tcx>, tcx: TyCtxt<'tcx>,callgraph: &'a CallGraph<'tcx>,param_env: ParamEnv<'tcx>,) -> Self {
        Self {
            instance,
            body,
            tcx,
            graph: Default::default(),
            callgraph,
            worklist_instance:Default::default(),
            param_env,
        }
    }
 
    /// 处理赋值语句
    fn process_assignment(&mut self, place: &Place<'tcx>, rvalue: &Rvalue<'tcx>) {
        if let Some(instance_id) = self.callgraph.instance_to_index(self.instance)
        {
            let lhs_pattern = Self::process_place(place.as_ref());
            let rhs_pattern = Self::process_rvalue(rvalue);
            match (lhs_pattern, rhs_pattern) {
                
                // a = &b
                (AccessPattern::Direct(lhs), Some(AccessPattern::Ref(rhs))) => {
                    self.graph.add_address(lhs, rhs,instance_id);
                }
                // a = b
                (AccessPattern::Direct(lhs), Some(AccessPattern::Direct(rhs))) => {
                    self.graph.add_copy(lhs, rhs,instance_id);
                }
                // a = Constant
                (AccessPattern::Direct(lhs), Some(AccessPattern::Constant(rhs))) => {
                    self.graph.add_copy_constant(lhs, rhs,instance_id);
                }
                // a = *b  
                (AccessPattern::Direct(lhs), Some(AccessPattern::Indirect(rhs))) => {
                    self.graph.add_load(lhs, rhs,instance_id);
                }
                // *a = b
                (AccessPattern::Indirect(lhs), Some(AccessPattern::Direct(rhs))) => {
                    self.graph.add_store(lhs, rhs,instance_id);
                }
                // *a = Constant
                (AccessPattern::Indirect(lhs), Some(AccessPattern::Constant(rhs))) => {
                    self.graph.add_store_constant(lhs, rhs,instance_id);
                }
                // a = &((*b).0)  _8 = &((*_1).0: std::sync::Arc<std::sync::Mutex<i32>>);
                (AccessPattern::Direct(lhs), Some(AccessPattern::Field(rhs))) => {
                    self.graph.add_field_address(lhs, rhs, instance_id)
                }
                _ => {}
            }
        }
    }

    /// 处理赋值语句左值place
    fn process_place(place_ref: PlaceRef<'tcx>) -> AccessPattern<'tcx> {
        match place_ref {
            PlaceRef {
                local: l,
                projection: [ProjectionElem::Deref, ref remain @ ..],
            } => AccessPattern::Indirect(PlaceRef {
                local: l,
                projection: remain,
            }),// *a=...
            _ => AccessPattern::Direct(place_ref), // a=...
        }
    }

    /// 处理赋值语句右值
    fn process_rvalue(rvalue: &Rvalue<'tcx>) -> Option<AccessPattern<'tcx>> {
        match rvalue {
            Rvalue::Use(operand) | Rvalue::Repeat(operand, _) | Rvalue::Cast(_, operand, _) => {
                match operand {
                    // Operand::Move(place) | Operand::Copy(place) => {
                    //     Some(AccessPattern::Direct(place.as_ref()))
                    // }
                    Operand::Move(place) | Operand::Copy(place) => match place.as_ref() {
                        // _9 = (_8.0: *const alloc::sync::ArcInner<T>)
                        // PlaceRef {
                        //     local: l,
                        //     projection: [ProjectionElem::Field(_, _), ..],
                        // } => Some(AccessPattern::Field(place.as_ref())), 

                        PlaceRef {
                            local: l,
                            projection: [ProjectionElem::Deref, ref remain @ ..],
                        } => Some(AccessPattern::Indirect(PlaceRef {
                            local: l,
                            projection: remain,
                        })),// ..=*q
                        _ => Some(AccessPattern::Direct(place.as_ref())),
                    }
                    Operand::Constant(box Constant {
                        span: _,
                        user_ty: _,
                        literal,
                    }) => Some(AccessPattern::Constant(*literal)),
                }
            },

            Rvalue::Ref(_, _, place) | Rvalue::AddressOf(_, place) => match place.as_ref() {
                PlaceRef {
                    local: l,
                    projection: [..,ProjectionElem::Field(_, _),],
                } => Some(AccessPattern::Field(place.as_ref())), // ..=&((*_1).0) 1106  a = &((*b).0)

                PlaceRef {
                    local: l,
                    projection: [ProjectionElem::Deref, ref remain @ ..],
                } => Some(AccessPattern::Direct(PlaceRef {
                    local: l,
                    projection: remain,
                })), // p=&*q
                
                _ => Some(AccessPattern::Ref(place.as_ref())),
                
            },
            _ => None,
        }
    }

    /// 处理函数调用参数 pi--|copy|-->argi
    /// dest = func(p1,p2,...)
    /// fn func(arg1,arg2,...) =>
    fn process_call_arg(&mut self, real: PlaceRef<'tcx>, formal: PlaceRef<'tcx>, callee_instance_id:InstanceId) {
        if let Some(instance_id) = self.callgraph.instance_to_index(self.instance)
        {
            // println!("CALL_ARG:CALLER_InstanceID{:?},real{:?},CALLEE_InstanceID{:?},formal{:?}",instance_id,real,callee_instance_id,formal);
            self.graph.add_call_arg(real, formal, instance_id, callee_instance_id)
            
        }
        
    }
    
    /// 处理函数调用参数 arg--|copy|-->dest
    /// dest: *const T = Vec::as_ptr(arg: &Vec<T>) =>
    fn process_call_arg_dest_inter(&mut self, arg: PlaceRef<'tcx>, dest: PlaceRef<'tcx>) {
        if let Some(instance_id) = self.callgraph.instance_to_index(self.instance)
        {
             self.graph.add_copy(dest, arg,instance_id);
        }
       
    }

     /// 处理闭包间的参数传递
     ///  _18 = {closure@src/main.rs:13:28: 13:35} { lock_a2: move _3, lock_b2: move _7 };
     /// fn one_closure_one_caller::{closure#0}(_1: {closure@src/main.rs:13:28: 13:35}) -> () {...}
     /// TODO: 不够准确
    fn process_closure(&mut self, capture: PlaceRef<'tcx>, closure_arg: PlaceRef<'tcx>, closure_instance_id:InstanceId) {
        if let Some(instance_id) = self.callgraph.instance_to_index(self.instance)
        {
             self.graph.add_closure(capture, closure_arg,instance_id,closure_instance_id);
            
        }
       
    }

    /// 处理智能指针Arc::clone
    /// dest: Arc<T> = Arc::clone(arg: &Arc<T>) or dest: T = ptr::read(arg: *const T) =>
    /// arg--|load|-->dest and
    /// arg--|alias_copy|-->dest
    fn process_alias_copy(&mut self, arg: PlaceRef<'tcx>, dest: PlaceRef<'tcx>) {
        if let Some(instance_id) = self.callgraph.instance_to_index(self.instance)
        {
            self.graph.add_load(dest, arg,instance_id);
            self.graph.add_alias_copy(dest, arg,instance_id);
        }
        
    }

    /// 处理域敏感
    /// Place1{local1, &[f0]}  Place2{local1, &[f0,f1]}
    /// Place1.projection是Place2.projection的前缀
    /// 添加约束Place1 = Place2
    fn add_partial_copy(&mut self) {
        if let Some(instance_id) = self.callgraph.instance_to_index(self.instance)
        {
            let nodes = self.graph.nodes();
            for (idx, n1) in nodes.iter().enumerate() {
                for n2 in nodes.iter().skip(idx + 1) {
                    if let (ConstraintNode::Place(p1, instance_id1), ConstraintNode::Place(p2, instance_id2)) = (n1, n2) {
                        if p1.local == p2.local {
                            if p1.projection.len() > p2.projection.len() {
                                if &p1.projection[..p2.projection.len()] == p2.projection {
                                    self.graph.add_copy(*p2,*p1,*instance_id1);
                                }
                            } else if &p2.projection[..p1.projection.len()] == p1.projection {
                                self.graph.add_copy(*p1,*p2,*instance_id2);
                            }
                        }
                    }
                }
            }
        }
    }
    
    /// 遍历所有的instance的MIR body 创建初始约束图
    fn analyze(
        &mut self,
        instances: Vec<&'a Instance<'tcx>>,
    ){
        //所有的instance 
       for instance_temp in instances{
            let body_temp = self.tcx.instance_mir(instance_temp.def);
            self.body = body_temp;
            self.instance = &instance_temp;
            self.visit_body(body_temp);
       }
    }

    
    /// 返回创建的初始约束图
    fn finish(mut self) -> ConstraintGraph<'tcx> {
        self.add_partial_copy();
        self.graph
    }
}

impl<'a, 'tcx> Visitor<'tcx> for ConstraintGraphCollector<'a, 'tcx> {
    /// 处理赋值语句
    fn visit_statement(&mut self, statement: &Statement<'tcx>, _location: Location) {
        match &statement.kind {
            StatementKind::Assign(box (place, rvalue)) => {
                self.process_assignment(place, rvalue);//palce左值 rvalue右值
            }
            StatementKind::FakeRead(_)
            | StatementKind::SetDiscriminant { .. }
            | StatementKind::Deinit(_)
            | StatementKind::StorageLive(_)
            | StatementKind::StorageDead(_)
            | StatementKind::Retag(_, _)
            | StatementKind::AscribeUserType(_, _)
            | StatementKind::Coverage(_)
            | StatementKind::Nop
            | StatementKind::Intrinsic(_)
            | StatementKind::PlaceMention(_)
            | StatementKind::ConstEvalCounter => {}
        }
    } 

    ///处理函数调用
    fn visit_terminator(&mut self, terminator: &Terminator<'tcx>, _location: Location) {
        if let TerminatorKind::Call {
            func,//被调用的函数 Oeprand
            args,//参数 Vec<Operand>
            destination, //Place
            target,
            unwind,
            call_source,
            fn_span
        } = &terminator.kind
        {
            let func_ty = func.ty(self.body, self.tcx);
            let func_ty = self.instance.subst_mir_and_normalize_erasing_regions(
                self.tcx,
                self.param_env,
                ty::EarlyBinder::bind(func_ty),
            );
            //处理函数调用 实参和形参 
            // _10 = swap(move _11, move _14); fn swap(_1: &Mutex<i32>, _2: &Mutex<i32>);  _11 ---> _1, _14 ---> _2
            if let ty::FnDef(def_id, substs) = *func_ty.kind() {
                if let Some(callee) = Instance::resolve(self.tcx, self.param_env, def_id, substs) 
                    .ok()
                    .flatten()
                {
                    if let Some(callee_instance_id) = self.callgraph.instance_to_index(&callee){
                        if let Some(node) = self.callgraph.instance_to_CallGraphNode(&callee){
                            let formal_arg_vec = self.callgraph.getArgs(node, self.tcx);
                            let length_match = formal_arg_vec.len() == args.len();
                            if length_match {
                                let combined = args.iter().zip(formal_arg_vec.iter());
                                for (real, formal) in combined {
                                     if let Some(real) = real.place(){
                                        self.process_call_arg(real.as_ref(), formal.as_ref(), callee_instance_id);
                                     }
                                }
                            }
                            
                         }
                    }                    
                }
            }  
           

           // 处理dest和返回值 _4 = Mutex::<i32>::lock(_2) ， _2 ----> _4
           // TODO: 这里不够准确 需要修改    
           match (args.as_slice(), destination) {
            (&[Operand::Move(arg)], dest) => {
                self.process_call_arg_dest_inter(arg.as_ref(), dest.as_ref());
            }
            (&[Operand::Move(arg), _], dest) => {
                let func_ty1 = func.ty(self.body, self.tcx);
                if let TyKind::FnDef(def_id, _) = func_ty1.kind() {
                    if ownership::is_index(*def_id, self.tcx) {
                        return self.process_call_arg_dest_inter(arg.as_ref(), dest.as_ref());
                    }
                }
            }
            (&[Operand::Copy(arg)], dest) => {
                self.process_call_arg_dest_inter(arg.as_ref(), dest.as_ref());
            }
            (&[Operand::Copy(arg), _], dest) => {
                let func_ty1 = func.ty(self.body, self.tcx);
                if let TyKind::FnDef(def_id, _) = func_ty1.kind() {
                    if ownership::is_index(*def_id, self.tcx) {
                        return self.process_call_arg_dest_inter(arg.as_ref(), dest.as_ref());
                    }
                }
            }
            _ => {}
        }
        }
        
    } 


    /// 处理闭包 Closure 
    /// TODO: 这里不够准确 需要修改   
    /// 只能根据捕获参数的类型寻找闭包内部相同类型的变量，不精确，没找到rust提供的合适Closure处理函数
    fn visit_local_decl(&mut self, local: Local, local_decl: &LocalDecl<'tcx>) { 
        let func_ty = self.instance.subst_mir_and_normalize_erasing_regions(
            self.tcx,
            self.param_env,
            ty::EarlyBinder::bind(local_decl.ty),
        ); 
       
        if let TyKind::Closure(def_id, substs) = func_ty.kind() {  //Closure(DefId, &'tcx List<GenericArg<'tcx>>)
            match self.body.local_kind(local) {
                LocalKind::Arg | LocalKind::ReturnPointer => {
                }
                _ => {
                    let closure_args = ClosureArgs { args: substs };
                    let upcar_tys = closure_args.upvar_tys();
                    if let Some(closure) =
                        Instance::resolve(self.tcx, self.param_env, *def_id, substs)
                            .ok()
                            .flatten()
                    {
                        if let Some(closure_instance_id) = self.callgraph.instance_to_index(&closure){
                            if let Some(node) = self.callgraph.instance_to_CallGraphNode(&closure){
                                if let Some(instance_id) = self.callgraph.instance_to_index(self.instance){
                                    
                                    // println!("PROCESS CLOSURE................");
                                    for upcar_ty in upcar_tys.iter(){ //捕获参数的类型 
                                        let closure_arg_vec = self.callgraph.getClosureArg(node, self.tcx,upcar_ty);//闭包内部类型相同的
                                        //upcar_tys[0] --> formal.0 
                                        for (local, local_ty) in self.body.local_decls.iter_enumerated() {//当前body里类型相同的
                                            if local_ty.ty == upcar_ty {
                                                let place = Place::from(local);
                                                // println!("instance_id:{:?} local:{:?}, capture.local_ty:{:?}",instance_id,place,upcar_ty);
                                                for c in closure_arg_vec.iter(){
                                                    self.process_closure(place.as_ref(), c.as_ref(), closure_instance_id);
                                                    // println!("instance_id:{:?} local:{:?}, closure_instance_id{:?},local:{:?}",instance_id,place,closure_instance_id,c);
                                                }
                                               
                                            }
                                        }
                                    }
                                }
                                   
                                
                             }
                        }             

                       




                        
                    }
                }
            }
        }
    }
}