#![cfg_attr(test, feature(test))]
#![warn(rust_2018_idioms)]

use rayon::prelude::*;
use std::sync::{Arc, Condvar, Mutex};
use std::thread;
use std::{env, io, io::prelude::*, process::exit};

mod cpu_time;
mod life;
mod matmul;
mod mergesort;
mod nbody;
mod noop;
mod quicksort;
mod sieve;
mod tsp;

// these are not "full-fledged" benchmarks yet,
// they only run with cargo bench
#[cfg(test)]
mod factorial;
#[cfg(test)]
mod fibonacci;
#[cfg(test)]
mod find;
#[cfg(test)]
mod join_microbench;
#[cfg(test)]
mod map_collect;
#[cfg(test)]
mod pythagoras;
#[cfg(test)]
mod sort;
#[cfg(test)]
mod str_split;
#[cfg(test)]
mod tree;
#[cfg(test)]
mod vec_collect;

#[cfg(test)]
extern crate test;

const USAGE: &str = "
Usage: rayon-demo bench
       rayon-demo <demo-name> [ options ]
       rayon-demo --help

A collection of different benchmarks of Rayon. You can run the full
benchmark suite by executing `cargo bench` or `rayon-demo bench`.

Alternatively, you can run individual benchmarks by running
`rayon-demo foo`, where `foo` is the name of a benchmark. Each
benchmark has its own options and modes, so try `rayon-demo foo
--help`.

Benchmarks:

  - life : Conway's Game of Life.
  - nbody: A physics simulation of multiple bodies attracting and repelling
           one another.
  - sieve: Finding primes using a Sieve of Eratosthenes.
  - matmul: Parallel matrix multiplication.
  - mergesort: Parallel mergesort.
  - noop: Launch empty tasks to measure CPU usage.
  - quicksort: Parallel quicksort.
  - tsp: Traveling salesman problem solver (sample data sets in `data/tsp`).
";

fn usage() -> ! {
    let _ = writeln!(&mut io::stderr(), "{}", USAGE);
    exit(1);
}

fn main() {
    let args: Vec<String> = env::args().collect();

    if args.len() < 2 {
        usage();
    }

    let bench_name = &args[1];
    match &bench_name[..] {
        "matmul" => matmul::main(&args[1..]),
        "mergesort" => mergesort::main(&args[1..]),
        "nbody" => nbody::main(&args[1..]),
        "quicksort" => quicksort::main(&args[1..]),
        "sieve" => sieve::main(&args[1..]),
        "tsp" => tsp::main(&args[1..]),
        "life" => life::main(&args[1..]),
        "noop" => noop::main(&args[1..]),
        // "std-join" => std_join(),
        // "join" => join_deadlock(),
        // "per_iter" => per_iter_deadlock(),
        "condvar" => incorrect_use_condvar(),
        _ => usage(),
    }
}

fn seeded_rng() -> rand_xorshift::XorShiftRng {
    use rand::SeedableRng;
    use rand_xorshift::XorShiftRng;
    let mut seed = <XorShiftRng as SeedableRng>::Seed::default();
    (0..).zip(seed.as_mut()).for_each(|(i, x)| *x = i);
    XorShiftRng::from_seed(seed)
}

fn per_iter_deadlock() {
    let lock = Arc::new(Mutex::new(0));

    let lock_clone = Arc::clone(&lock);
    let guard = lock.lock().unwrap();

    (0..10).into_par_iter().for_each(|_| {
        let _inner_guard = lock_clone.lock().unwrap();
    });
}

fn join_deadlock() {
    let data = Arc::new(Mutex::new(0));

    let lock = data.lock().unwrap();

    rayon::join(
        || {
            let mut guard = data.lock().unwrap();
            *guard += 1;
        },
        || {
            let mut guard = data.lock().unwrap();
            *guard += 1;
        },
    );
}

fn incorrect_use_condvar() {
    let mu1 = Arc::new(Mutex::new(1));
    let mu2 = mu1.clone();
    let pair1 = Arc::new((Mutex::new(false), Condvar::new()));
    let pair2 = pair1.clone();
    let th1 = thread::spawn(move || {
        let i1 = mu1.lock().unwrap();
        let (lock, cvar) = &*pair1;
        let mut started = lock.lock().unwrap();
        while !*started {
            //*started永远为false
            started = cvar.wait(started).unwrap();
        }
    });

    let i2 = mu2.lock().unwrap();
    let (lock, cvar) = &*pair2;

    let mut started = lock.lock().unwrap();
    *started = true;
    cvar.notify_one();

    th1.join().unwrap();
}

fn std_join() {
    let lock_a1 = Arc::new(Mutex::new(1));
    let lock_a2 = lock_a1.clone();
    let lock_b1 = Arc::new(Mutex::new(true));
    let lock_b2 = lock_b1.clone();
    {
        let _b = lock_b1.lock().unwrap();
        let _a = lock_a1.lock().unwrap();
    }
    let th = thread::spawn(move || {
        let _a = lock_a2.lock().unwrap();
        let _b = lock_b2.lock().unwrap();
    });
    th.join().unwrap();
}
