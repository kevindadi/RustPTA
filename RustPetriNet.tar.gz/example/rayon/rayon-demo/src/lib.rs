// Make sure the examples in the main README actually compile.
#[cfg(doctest)]
doc_comment::doctest!("../../README.md");
