mod run_length_encoding;

pub use self::run_length_encoding::{run_length_decode, run_length_encode};
