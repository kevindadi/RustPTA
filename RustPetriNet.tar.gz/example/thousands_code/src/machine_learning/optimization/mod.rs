pub mod adam;
pub mod gradient_descent;

pub use self::adam::Adam;
pub use self::gradient_descent::gradient_descent;
