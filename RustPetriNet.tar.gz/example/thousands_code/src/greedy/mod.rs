pub mod stable_matching;

pub use self::stable_matching::stable_matching;
